function logout() {
    if (confirm("Deseja realmente sair?")) {
        window.location.href = "index.html";
    }
}